import React from 'react';
export default function LandingPage() {
  return <div className="text-white bg-gray-900 h-screen flex items-center justify-center">Welcome to ReWear</div>;
}
