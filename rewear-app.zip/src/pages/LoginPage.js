import React from 'react';
export default function LoginPage() {
  return <div className="text-white bg-gray-900 h-screen flex items-center justify-center">Login Page</div>;
}
