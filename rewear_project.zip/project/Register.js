document.getElementById("registerForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();
  const msg = document.getElementById("registerMsg");

  if (!name || !email || !username || !password) {
    msg.textContent = "All fields are required.";
    msg.classList.remove("hidden");
    msg.classList.remove("text-green-400");
    msg.classList.add("text-red-400");
    return;
  }

  const user = { name, email, username, password };
  localStorage.setItem("registeredUser", JSON.stringify(user));

  msg.textContent = "Registration successful! Redirecting to login...";
  msg.classList.remove("hidden");
  msg.classList.remove("text-red-400");
  msg.classList.add("text-green-400");

  document.getElementById("registerForm").reset();

  setTimeout(() => {
    window.location.href = "login.html";
  }, 2000);
});