document.getElementById("loginForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();
  const errorMsg = document.getElementById("errorMsg");

  if (!username || !password) {
    errorMsg.textContent = "Please fill all fields.";
    errorMsg.classList.remove("hidden");
    return;
  }

  const storedUser = JSON.parse(localStorage.getItem("registeredUser"));

  if (storedUser && username === storedUser.username && password === storedUser.password) {
    errorMsg.classList.add("hidden");
    alert("Login successful!");
    window.location.href = "landing.html"; // You can customize this page
  } else {
    errorMsg.textContent = "Invalid login. Try again.";
    errorMsg.classList.remove("hidden");
  }
});